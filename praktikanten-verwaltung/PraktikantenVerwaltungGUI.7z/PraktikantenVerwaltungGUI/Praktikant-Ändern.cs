﻿using Schichten;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PraktikantVerwaltungGUI
{
    public partial class PraktikantÄndern : Form
    {
        public Fachkonzept GUIFachkonzept;
        public PraktikantModel oldP;
        public void TransparencyButtons()
        {
            btnSpeichern.FlatStyle = FlatStyle.Popup;
            btnLoeschen.FlatStyle = FlatStyle.Popup;
            btnAbbruch.FlatStyle = FlatStyle.Popup;
        }
        public PraktikantÄndern(string praktikantString, Fachkonzept fachkonzept)
        {
            InitializeComponent();

            int praktikantNr = 0;
            string praktikantName = "";

            praktikantNr = Convert.ToInt32(praktikantString.Split(',')[1]);
            praktikantName = praktikantString.Split(',')[0];

            oldP = new PraktikantModel();
            oldP.Name = praktikantName;
            oldP.Praktikant_NR = praktikantNr;


            GUIFachkonzept = fachkonzept;
            PraktikantModel praktikantModel = GUIFachkonzept.getPraktikanten().ToList().Where(x => x.Praktikant_NR == praktikantNr && x.Name == praktikantName).FirstOrDefault();
            tbxName.Text = praktikantModel.Name;
            List<AbteilungModel> abteilungList = GUIFachkonzept.getAbteilungen();

            int cntAbteilung = 0;

            foreach (var item in abteilungList)
            {
                cboAbteilung.Items.Add(item.Bezeichnung + "," + item.Abteilung_NR);
                if(item.Abteilung_NR != praktikantModel.ZugewieseneAbteilung)
                {
                    cntAbteilung++;
                }
                
            }

            if(praktikantModel.ZugewieseneAbteilung == -1)
            {
                cboAbteilung.SelectedItem = null;
            }
            else
            {
                cboAbteilung.SelectedIndex = cntAbteilung;
            }
        }

        private void tbxName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAbbruch_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;

            Close();
        }

        private void btnLoeschen_Click(object sender, EventArgs e)
        {
            GUIFachkonzept.deletePraktikant(oldP);
            this.DialogResult = DialogResult.OK;
            MessageBox.Show(string.Format("Praktikant: {0} erfolgreich gelöscht!", oldP.Name));
            Close();
        }

        private void PraktikantÄndern_Load(object sender, EventArgs e)
        {

        }

        private void btnSpeichern_Click(object sender, EventArgs e)
        {
            AbteilungModel newAbt = new AbteilungModel();
            PraktikantModel newPrakt = new PraktikantModel();

            List<AbteilungModel> abteilungList = GUIFachkonzept.getAbteilungen();

            int abteilungNr = Convert.ToInt32(cboAbteilung.SelectedItem.ToString().Split(',')[1]);

            newPrakt.Name = tbxName.Text;
            newPrakt.ZugewieseneAbteilung = abteilungList.Where(x => x.Abteilung_NR == abteilungNr).FirstOrDefault().Abteilung_NR;
            newPrakt.Praktikant_NR = -1;

            
            string oldAbteilung = "nicht zugewiesen";
            if (oldP.ZugewieseneAbteilung != -1)
            {
                oldAbteilung = abteilungList.Where(x => x.Abteilung_NR == oldP.ZugewieseneAbteilung).FirstOrDefault().Bezeichnung;
            }
                
            string newAbteilung = abteilungList.Where(x => x.Abteilung_NR == newPrakt.ZugewieseneAbteilung).FirstOrDefault().Bezeichnung;
            string oldName = oldP.Name;
            string newName = newPrakt.Name;

            GUIFachkonzept.changePraktikant(oldP, newPrakt);

            MessageBox.Show(string.Format("Praktikant erfolgreich gespeichert! ({0},{1} => {2},{3})", oldName, oldAbteilung, newName, newAbteilung));
            this.DialogResult = DialogResult.OK;
            Close();



        }

        private void cboAbteilung_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
