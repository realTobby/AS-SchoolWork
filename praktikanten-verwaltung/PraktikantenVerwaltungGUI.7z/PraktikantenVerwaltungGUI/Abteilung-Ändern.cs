﻿using Schichten;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PraktikantVerwaltungGUI
{
    public partial class Abteilung_Ändern : Form
    {
        private Fachkonzept GUIFachkonzept;
        private string AbteilungString = "";
        public void TransparencyButtons()
        {
            btnSpeichern.FlatStyle = FlatStyle.Popup;
            btnLoeschen.FlatStyle = FlatStyle.Popup;
            btnAbbruch.FlatStyle = FlatStyle.Popup;
        }
        public Abteilung_Ändern(string abteilungString, Fachkonzept konzept)
        {
            InitializeComponent();
            GUIFachkonzept = konzept;
            AbteilungString = abteilungString;
            string abteilungName = AbteilungString.Split(',')[0];

            tbxAbteilung.Text = abteilungName;
        }

        private void lblAbteilung_Click(object sender, EventArgs e)
        {

        }

        private void Abteilung_Ändern_Load(object sender, EventArgs e)
        {

        }

        private void btnSpeichern_Click(object sender, EventArgs e)
        {
            int abteilungNummer = Convert.ToInt32(AbteilungString.Split(',')[1]);
            string abteilungName = AbteilungString.Split(',')[0];

            AbteilungModel oldAbt = new AbteilungModel();
            oldAbt.Abteilung_NR = abteilungNummer;
            oldAbt.Bezeichnung = abteilungName;

            AbteilungModel newAbt = new AbteilungModel();
            newAbt.Bezeichnung = tbxAbteilung.Text;
            newAbt.Abteilung_NR = oldAbt.Abteilung_NR;

            GUIFachkonzept.changeAbteilung(oldAbt, newAbt);

            this.DialogResult = DialogResult.OK;
            MessageBox.Show(string.Format("Abteilung erfolgreich gespeichert! {0} => {1}", oldAbt.Bezeichnung, newAbt.Bezeichnung));
            Close();

        }

        private void btnLoeschen_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAbbruch_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
