﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSimulator
{
    public class BankingAccount
    {
        public int ID { get; set; }
        public int OWNER { get; set; }
        public double BALANCE { get; set; }
        public string NAME { get; set; }

    }
}
